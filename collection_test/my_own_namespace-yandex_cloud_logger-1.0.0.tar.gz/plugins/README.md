# Collections Plugins Directory

```
└── plugins
    ├── modules
        ├── my_own_module
```
